from django.shortcuts import render, redirect
from django.contrib.auth import authenticate, login, logout
from django.contrib.auth.decorators import login_required
from .forms import *
from django.http import HttpResponse
from datetime import date, timedelta
import json
from django.db.models import Q

# 메인페이지
def index(request):
    return render(request,'index.html')

# 로그인
def login_request(request):
    form = LoginForm(request.POST or None)
    msg = None
    if request.method == "POST":
        if form.is_valid():
            username = form.cleaned_data.get("username")
            password = form.cleaned_data.get("password")
            user = authenticate(username=username, password=password)
            if user is not None:
                login(request, user)
                return redirect("/")
            else:
                msg = '아이디 또는 비밀번호를 다시 확인해주세요.'
        else:
            msg = 'Error validating the form'
    return render(request, 'authentication/login.html', {'form': form, 'msg': msg})

# 로그아웃
def logout_request(request):
    logout(request)
    return redirect("index")

# FAQ
def faq(request):
    print("파티란? OTT 계정 공유를 위한 모임입니다.")

    print("파티 이용법: 1. 파티 만들기를 통해 파티장이 되어 신청자를 받는다. 혹은 각 OTT별로 이미 만들어진 파티의 신청자가 된다. ")

    print("            2. 파티장은 원하는 OTT를 시작일과 기간을 지정해 파티를 생성한다. "),

    print("            3. 파티장의 경우 24시간 이내로 계좌에 입금된 신청자를 파티의 가입을 승인한다.")         

    print("             파티의 신청자가 되었을 경우 24시간 이내로 파티장의 계좌로 입금하면 파티장이 확인 후 파티 가입을 승인한다.")
   
    return render(request,"faq.html")


# 회원가입
def signup(request):
    form = SignUpForm(request.POST or None)
    if request.method == "POST":
        if form.is_valid():
            form.save()
            username = form.cleaned_data.get("username")
            raw_password = form.cleaned_data.get("password1")
            user = authenticate(username=username, password=raw_password)
            return redirect("index")

    return render(request, "authentication/signup.html", {"form": form})


# 파티만들기
def makeParty(request):
    form = PartyForm(request.POST or None)
    if request.method == "POST":
        if form.is_valid():
            party = form.save(commit=False)
            party.user=request.user
            form.save()
            return redirect('makeParty')

    return render(request, "addParty.html", {"form": form})

# 파티리스트
def partyList(request, category_id):
    category = Category.objects.get(id=category_id)
    parties = Party.objects.filter(category=category).order_by('start_date')
    partyList = []
    for party in parties:
        partyPersons = PartyPerson.objects.filter(party=party)
        if party.people_count > len(partyPersons):
            partyList.append(party)

    
    return render(request, 'partyList.html', {'category':category,'partyList':partyList})

# 파티리스트 검색 (날짜)
def partyListSearch(request,category_id):
    partyList = Party.objects.filter(start_date__range=[request.GET['startDate'], request.GET['endDate']]).values().all().order_by('start_date')
    category = Category.objects.get(id=category_id)
    return render(request, 'partyList.html', {'category':category,'partyList':partyList})

# 파티원 요청
def requestPartyPerson(request):
    if request.method == "POST":
        party=Party.objects.get(id=request.POST['partyId'])
        partyPerson = PartyPerson.objects.filter(party=party,user=request.user)
        message=""
        if partyPerson.exists():
            message = "이미 요청한 파티입니다."
        else:
            if party.user == request.user:
                message = "직접 등록한 파티입니다."
            partyRequest = PartyPerson(user=request.user,party=party)
            partyRequest.save()
            message = "파티원 요청에 성공했습니다."
        context = {'message': message,
                   }
        return HttpResponse(json.dumps(context), content_type="application/json")

# My 페이지 - 파티리스트 
def myParty(request):
    requestList = []
    requestYetList = []

    # 요청한 파티 모두
    partyPersonList = PartyPerson.objects.filter(user=request.user)

    for partyPerson in partyPersonList:
        
        if partyPerson.approved == False:
            # 아직 요청승인이 되지 않은 파티
            requestYetList.append(partyPerson.party)
        else:
            # 이용중인 파티
            requestList.append(partyPerson.party)

    # 내가 파티장인 파티  
    myPartyList = Party.objects.filter(user=request.user)

    myPartiesList = []

    for party in myPartyList:
        myParties = {}
        myParties["party"] = party
        partyPersons = PartyPerson.objects.filter(party=party)
        myParties["partyPersons"] = partyPersons
        myParties["remaining"] = party.people_count - len(partyPersons)
        myPartiesList.append(myParties)

    print(myPartiesList)
    

    return render(request,'myParty.html',{'myPartiesList':myPartiesList,'requestList':requestList,'requestYetList':requestYetList})

# 파티원 승낙
def confirmParty(request):
    if request.method == "POST":
        partyPerson_id = request.POST['partyPersonId']
        partyPerson=PartyPerson.objects.get(id=partyPerson_id)

        partyPerson.approved = True

        partyPerson.save()
        message = "최종 수락하셨습니다."
        context = {'message': message,
                   }
        return HttpResponse(json.dumps(context), content_type="application/json")
    
# 파티원 거절
def rejectParty(request):
    if request.method == "POST":
        partyPerson_id = request.POST['partyPersonId']
        partyPerson=PartyPerson.objects.get(id=partyPerson_id)

        partyPerson.delete()

        message = "최종 거절하셨습니다."
        context = {'message': message,
                   }
        return HttpResponse(json.dumps(context), content_type="application/json")

