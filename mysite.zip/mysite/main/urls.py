from django.contrib import admin
from django.urls import path, include
from .views import *
from django.conf import settings
from django.contrib.auth.views import LogoutView
from django.conf.urls.static import static

urlpatterns = [
    path('', index, name="index"),

    path('login/', login_request, name="login_request"),
    path('logout/', logout_request, name="logout_request"),
    # path("logout/", LogoutView.as_view(), name="logout"),
    path('signup/', signup, name="signup"),

    path('faq',faq, name="faq"),
    path('make-party/',makeParty, name="makeParty"),
    path('party-list/<int:category_id>',partyList, name='partyList'),
    path('party-list-search/<int:category_id>',partyListSearch, name="partyListSearch"),

    path('request-party-person',requestPartyPerson,name='requestPartyPerson'),

    path('myParty',myParty, name='myParty'),

    path('confirmParty',confirmParty,name="confirmParty"),
    path('rejectParty',rejectParty, name="rejectParty"),

] + static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)