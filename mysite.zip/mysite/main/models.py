from django.db import models
from django.contrib.auth.models import User

# Create your models here.
class Category(models.Model):
    name = models.CharField(max_length=100, blank=False, null=False)
    image = models.ImageField(upload_to='static/images/%Y/%m/%d', default='static/images/no_image.png')
    def __str__(self):
        return self.name

class Party(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE, null=True)
    category = models.ForeignKey(Category, on_delete=models.CASCADE)
    start_date = models.DateField(blank=True, null=True)
    period = models.IntegerField(blank=True, null=True)
    people_count = models.IntegerField(blank=True, null=True)
    bank = models.CharField(max_length=100, blank=False, null=False)
    bank_number = models.CharField(max_length=100, blank=False, null=False)
    bank_host = models.CharField(max_length=100, blank=True, null=True, default="")
    platform_id = models.CharField(max_length=100, blank=False, null=False)
    platform_pw = models.CharField(max_length=100, blank=False, null=False)
    created_at = models.DateTimeField(auto_now_add=True, null=True)
    updated_at = models.DateTimeField(auto_now=True, null=True)


class PartyPerson(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE, null=True)
    approved = models.BooleanField(default=False)
    party = models.ForeignKey(Party, on_delete=models.CASCADE)

    def __str__(self):
        return self.user.username