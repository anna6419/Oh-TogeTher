from django import forms
from django.contrib.auth.forms import UserCreationForm
from django.contrib.auth.models import User
from .models import *
import datetime

class LoginForm(forms.Form):
    username = forms.CharField(
        widget=forms.TextInput(
            attrs={
                "placeholder": "아이디를 입력해주세요.",
                "class": "form-control"
            }
        ))
    password = forms.CharField(
        widget=forms.PasswordInput(
            attrs={
                "placeholder": "비밀번호를 입력해주세요.",
                "class": "form-control"
            }
        ))


class SignUpForm(UserCreationForm):
    username = forms.CharField(
        widget=forms.TextInput(
            attrs={
                "placeholder": "아이디를 입력해주세요.",
                "class": "form-control"
            }
        ))
    password1 = forms.CharField(
        widget=forms.PasswordInput(
            attrs={
                "placeholder": "비밀번호를 입력해주세요.",
                "class": "form-control"
            }
        ))
    password2 = forms.CharField(
        widget=forms.PasswordInput(
            attrs={
                "placeholder": "비밀번호를 다시 입력해주세요.",
                "class": "form-control"
            }
        ))
    name = forms.CharField(
        widget=forms.TextInput(
            attrs={
                "placeholder": "이름을 입력해주세요.",
                "class": "form-control"
            }
        ))
    phone_number = forms.CharField(
        widget=forms.TextInput(
            attrs={
                "placeholder": "휴대폰 번호를 입력해주세요.",
                "class": "form-control"
            }
        ))

    class Meta:
        model = User
        fields = ('username', 'password1', 'password2', 'name', 'phone_number')


PERIOD_CHOICES = (
    (1, '1개월'),
    (2, '2개월'),
    (3, '3개월'),
    (4, '4개월'),
    (5, '5개월'),
    (6, '6개월'),
    (7, '7개월'),
    (8, '8개월'),
    (9, '9개월'),
    (10, '10개월'),
    (11, '11개월'),
    (12, '12개월'),
)

class PartyForm(forms.ModelForm):
    model = Party
    class Meta:
        model = Party
        fields = ('category','platform_id', 'platform_pw', 'start_date','period', 'people_count','bank','bank_number','bank_host',)
        widgets = {
            'platform_id' : forms.TextInput(attrs={'placeholder' : '아이디를 입력해주세요.'}),
            'platform_pw': forms.TextInput(attrs={'placeholder': '비밀번호를 입력해주세요.'}),
            'start_date': forms.DateInput(format=('%m/%d/%Y'), attrs={'class':'form-control', 'placeholder':'날짜를 선택해주세요.', 'type':'date'}),
            'bank': forms.TextInput(attrs={'placeholder': '은행명을 입력해주세요.'}),
            'bank_number': forms.TextInput(attrs={'placeholder': '계좌번호를 입력해주세요.'}),
            'bank_host': forms.TextInput(attrs={'placeholder': '입금주명을 입력해주세요.'}),
            'period': forms.Select(choices=PERIOD_CHOICES)
        }
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.fields['category'].label = "공유 서비스"
        self.fields['platform_id'].label = "플랫폼 아이디"
        self.fields['platform_pw'].label = "플랫폼 비밀번호"
        self.fields['start_date'].label = "파티 시작일"
        self.fields['period'].label = "파티 기간"
        self.fields['people_count'].label = "모집인원수"
        self.fields['bank'].label = "은행명"
        self.fields['bank_number'].label = "계좌번호"
